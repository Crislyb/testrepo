'''
Ximena Cristina Borges Monsreal 
ID: 00559333
Ing en Animacion Digital
'''
from Animales import Mamifero

class Gato(Mamifero): 
    
    def __init__(self, n, p, b=0): 
        super().__init__(n,p)
        self.__nBigotes = b
        
    def imprimirG(self):
        print("Nombre: ", self.nombre)
        print("Peso: ", self._peso)
        print("Bigotes: ", self.__nBigotes)
