'''
Ximena Cristina Borges Monsreal 
ID: 00559333
Ing en Animacion Digital
'''
from Animales import Mamifero

class Ballena(Mamifero):
    def __init__(self, n="", p=0.0):
        super().__init__(n,p)
        
        
    def imprimirB(self):
        print("BALLENA ")
        print("Nombre: ", self.nombre)
        print("Peso: ", self._peso)