'''
Ximena Cristina Borges Monsreal 
ID: 00559333
Ing en Animacion Digital
'''
from Gato import Gato
from Vaca import Vaca
from Ballena import Ballena

momo = Gato("momo",5.3,8)
momo.imprimirG()

lola = Vaca("lola", 300,20)
lola.calcularCantidadComida()
lola.imprimirV()

willy = Ballena("Willy", 150000)
willy.imprimirB()
