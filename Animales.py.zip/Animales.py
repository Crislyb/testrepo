'''
Ximena Cristina Borges Monsreal 
ID: 00559333
Ing en Animacion Digital
'''
class Mamifero: 
    
    def __init__(self, n="", p=0):
        self.__nombre = n 
        self._peso = p
        
    @property
    def nombre(self): 
        return self.__nombre
          
    @nombre.setter 
    def nombre(self,n): 
        self.__nombre = n
    
