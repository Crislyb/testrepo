'''
Ximena Cristina Borges Monsreal 
ID: 00559333
Ing en Animacion Digital
'''
from Animales import Mamifero

class Vaca(Mamifero):
    def __init__(self, n="", p=0.0, l = 0.0):
        super().__init__(n,p)
        self.__litrosDeLeche=1
        
    def calcularCantidadComida(self):
        print("La vaca debe comer: ", self._peso*0.03, "kg de alimento al dia.")
        
    def imprimirV(self):
        print("Nombre: ", self.nombre)
        print("Peso: ", self._peso)
        print("Litros de leche ",self.__litrosDeLeche)
